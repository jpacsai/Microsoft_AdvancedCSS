﻿using System;

namespace Reverse.App {
    class Program {
        static void Main(string[] args) {
            char[] chars = "ABCDEFG ABCDEFGH".ToCharArray();
            ReverseWord(chars, 0, 6);
            ReverseWord(chars, 8, 15);
            string expected = "GFEDCBA HGFEDCBA";
            string actual = new string(chars);
            Console.WriteLine(expected == actual);
        }

        static char[] PrepareChars(params string[] strings) {
            string longString = string.Join(' ', strings);
            char[] result = longString.ToCharArray();
            return result;
        }

        static void ReverseWords(char[] chars) {
            int p = 0, q = 0;
            while (++q < chars.Length) {
                if (chars[q] == ' ') {
                    ReverseWord(chars, p, q - 1);
                    p = q + 1;
                }
            }
        }

        static void ReverseWord(char[] chars, int li, int hi) {
            while (li < hi) {
                Swap(chars, li++, hi--);
            }
        }

        private static void Swap(char[] chars, int li, int hi) {
            char temp = chars[li];
            chars[li] = chars[hi];
            chars[hi] = temp;
        }
    }
}
























