using System;
using Xunit;
using Fibonacci.Tools;

namespace Fibonacci.Test {
    public class FibonacciSequenceTest {

        // Test Case 1:
        [Fact]
        public void GetNumberAtNegativeIndex_Exception() {
            var seq = new FibonacciSequence();
            var ex = Assert.Throws<ArgumentOutOfRangeException>(() => {
                int actual = seq.Get(-1);
            });

            var expMsg = "The minimal index of Fibonacci Sequence is 0.";
            Assert.Contains(expMsg, ex.Message);
        }

        // Test Case 2:
        [Fact]
        public void GetNumberAtLargeIndex() {
            var seq = new FibonacciSequence();
            seq.Get(100000);
        }

        // Test Case 3:
        [Fact]
        public void GetNumberAtIndex100() {
            var seq = new FibonacciSequence();
            var actual = seq.Get(100);
            Assert.True(actual > 0);
        }

        // Test Case 4:
        [Fact]
        public void GetNumberAtIndex0To12_OK() {
            var seq = new FibonacciSequence();
            var exp = new int[] { 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144 };
            for (int i = 0; i <= 12; i++) {
                var actual = seq.Get(i);
                Assert.Equal(exp[i], actual);
            }
        }
    }
}