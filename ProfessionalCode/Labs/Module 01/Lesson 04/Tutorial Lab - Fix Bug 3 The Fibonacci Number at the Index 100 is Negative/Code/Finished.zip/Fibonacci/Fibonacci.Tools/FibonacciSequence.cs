﻿using System;
using System.Collections.Generic;

namespace Fibonacci.Tools {
    public class FibonacciSequence {
        private IDictionary<int, int> _sequence;

        public FibonacciSequence() {
            _sequence = new Dictionary<int, int>();
        }

        public int Get(int i) {
            const string msg1 = "The minimal index of Fibonacci Sequence is 0.";
            if (i < 0) throw new ArgumentOutOfRangeException(nameof(i), msg1);
            if (i == 0 || i == 1) return i;
            try {
                checked {
                    if (!_sequence.ContainsKey(i))
                        _sequence[i] = Get(i - 1) + Get(i - 2);
                }
            } catch (OverflowException ex) {
                string msg2 = $"Index {i} is out of the boundary.";
                throw new ArgumentOutOfRangeException(msg2, ex);
            }
            return _sequence[i];
        }
    }
}
