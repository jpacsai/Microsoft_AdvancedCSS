﻿using System;
using Fibonacci.Tools;

namespace Fibonacci.App {
    class Program {
        static void Main(string[] args) {
            var seq = new FibonacciSequence();
            var indexes = new int[] { 0, 1, 2, 3, 4, 5, 12 };
            foreach (var index in indexes) {
                Console.WriteLine($"Index:{index} FN:{seq.Get(index)}");
            }

            // Repro bugs:
            //var num = seq.Get(-1);
            //var num = seq.Get(100000);
            //var num = seq.Get(100);
            //Console.WriteLine(num);
        }
    }
}
