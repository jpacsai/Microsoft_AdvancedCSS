﻿using System;
using System.Collections.Generic;
using System.Text;
using DipInUnitTest.App;

namespace DipInUnitTest.Test {
    class MockEngine : IEngine {
        int _rpm;
        public MockEngine(int rpm) {
            _rpm = rpm;
        }

        public int RPM { get { return _rpm; } }
        public void Start() { }
        public void Stop() { }
        public void Work() { }
    }
}
