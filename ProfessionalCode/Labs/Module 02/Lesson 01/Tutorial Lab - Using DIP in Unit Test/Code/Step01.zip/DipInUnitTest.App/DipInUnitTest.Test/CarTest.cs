using System;
using DipInUnitTest.App;
using Xunit;

namespace DipInUnitTest.Test {
    public class CarTest {
        [Fact]
        public void Run_EngineRpm8000_OK() {
            var engine = new MockEngine(8000);
            var car = new Car(engine);
            car.Run();
            Assert.Equal(80, car.Speed);
        }

        [Fact]
        public void Run_EngineRpmLessThan0_Exception() {
            var engine = new MockEngine(-1);
            var car = new Car(engine);
            var ex = Assert.Throws<Exception>(() => car.Run());
            Assert.Equal("Warning! Please check the engine!", ex.Message);
        }

        [Fact]
        public void Run_EngineRpmGreaterThan8000_Exception() {
            var engine = new MockEngine(10000);
            var car = new Car(engine);
            var ex = Assert.Throws<Exception>(() => car.Run());
            Assert.Equal("Warning! Please check the engine!", ex.Message);
        }
    }
}
