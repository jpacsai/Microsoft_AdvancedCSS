﻿using System;

namespace DipInUnitTest.App {
    class Program {
        static void Main(string[] args) {
        }
    }

    public interface IEngine {
        int RPM { get; }
        void Start();
        void Work();
        void Stop();
    }

    public class Engine : IEngine {
        public int RPM { get; }
        public void Start() { /*implementation ...*/ }
        public void Work() { /*implementation ...*/ }
        public void Stop() { /*implementation ...*/ }
    }

    public class Car {
        private IEngine _engine;
        public Car(IEngine engine) {
            _engine = engine;
        }

        public int Speed { get; set; }
        public void Run() {
            if (_engine.RPM >= 0 && _engine.RPM <= 8000) {
                Speed = _engine.RPM / 100;
                Console.WriteLine($"Running at speed {Speed} MPH ...");
            } else {
                throw new Exception("Warning! Please check the engine!");
            }
        }
    }
}
