using System;
using DipInUnitTest.App;
using Moq;
using Xunit;

namespace DipInUnitTest.Test {
    public class CarTest {
        [Fact]
        public void Run_EngineRpm8000_OK() {
            var mock = new Mock<IEngine>();
            mock.Setup(e => e.RPM).Returns(8000);
            var engine = mock.Object;
            var car = new Car(engine);
            car.Run();
            Assert.Equal(80, car.Speed);
        }

        [Fact]
        public void Run_EngineRpmLessThan0_Exception() {
            var mock = new Mock<IEngine>();
            mock.Setup(e => e.RPM).Returns(-1);
            var engine = mock.Object;
            var car = new Car(engine);
            var ex = Assert.Throws<Exception>(() => car.Run());
            Assert.Equal("Warning! Please check the engine!", ex.Message);
        }

        [Fact]
        public void Run_EngineRpmGreaterThan8000_Exception() {
            var mock = new Mock<IEngine>();
            mock.Setup(e => e.RPM).Returns(10000);
            var engine = mock.Object;
            var car = new Car(engine);
            var ex = Assert.Throws<Exception>(() => car.Run());
            Assert.Equal("Warning! Please check the engine!", ex.Message);
        }
    }
}
