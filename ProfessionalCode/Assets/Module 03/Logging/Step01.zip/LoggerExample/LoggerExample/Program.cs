﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace LoggerExample {
    class Program {
        static void Main(string[] args) {
            var serviceProvider = new ServiceCollection()
                .AddLogging(builder => builder.AddDebug().AddConsole())
                .BuildServiceProvider();

            var logger = serviceProvider
                .GetRequiredService<ILogger<Program>>();

            logger.LogInformation("This is a message.");
            logger.LogWarning("This is a warning.");
            logger.LogError("This is an error.");

            serviceProvider.Dispose(); // flush the logging information
        }
    }
}
