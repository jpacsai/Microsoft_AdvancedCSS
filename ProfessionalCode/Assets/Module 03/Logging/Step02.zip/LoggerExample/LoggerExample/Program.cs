﻿using System.Diagnostics;
using System.Linq;
using System.Text;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace LoggerExample {
    class Program {
        static void Main(string[] args) {
            var serviceProvider = new ServiceCollection()
                .AddLogging(builder => builder.AddDebug().AddConsole())
                .BuildServiceProvider();

            var logger = serviceProvider
                .GetRequiredService<ILogger<Program>>();

            var chars = Enumerable.Repeat('A', 1000000);
            var original = new string(chars.ToArray());
            var stopwatch = new Stopwatch();

            // using string
            var str = original;
            stopwatch.Start();
            for (int i = 0; i < 10000; i++) {
                str += 'B';
            }
            stopwatch.Stop();
            var msg1 = $"String: {stopwatch.Elapsed.TotalSeconds}";
            LogTime(logger, stopwatch.Elapsed.TotalSeconds, msg1);

            // using StringBuilder
            var sb = new StringBuilder(original);
            stopwatch.Restart();
            for (int i = 0; i < 10000; i++) {
                sb.Append('B');
            }
            var result = sb.ToString();
            stopwatch.Stop();
            var msg2 = $"StringBuilder: {stopwatch.Elapsed.TotalSeconds}";
            LogTime(logger, stopwatch.Elapsed.TotalSeconds, msg2);

            serviceProvider.Dispose(); // flush the logging information
        }

        public static void LogTime(ILogger logger, double seconds, string msg) {
            if (seconds > 100)
                logger.LogError(msg);
            else if (seconds > 10)
                logger.LogWarning(msg);
            else if (seconds > 0)
                logger.LogInformation(msg);
        }
    }
}
