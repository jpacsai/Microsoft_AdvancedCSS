﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace TplExample.Client {
    class Program {
        static void Main(string[] args) {
            var tuples = new ConcurrentQueue<ValueTuple<double, double>>();
            for (int i = 0; i < 100; i++) {
                tuples.Enqueue((i, i));
            }

            var httpClient = new HttpClient();

            var count = 10;
            var tasks = new Task[count];
            for (int i = 0; i < count; i++) {
                tasks[i] = new Task(() => {
                    while (tuples.Count > 0) {
                        tuples.TryDequeue(out (double, double) tuple);
                        double a = tuple.Item1, b = tuple.Item2;
                        var url = $"http://localhost:5000/api/add?a={a}&b={b}";
                        var response = httpClient.GetAsync(url).Result;
                        if (response.IsSuccessStatusCode) {
                            var result = response.Content.ReadAsStringAsync().Result;
                            Console.WriteLine($"{a}+{b}={result}");
                        }
                    }
                });
            }

            foreach (var task in tasks) {
                task.Start();
            }

            Task.WaitAll(tasks);
        }
    }
}
