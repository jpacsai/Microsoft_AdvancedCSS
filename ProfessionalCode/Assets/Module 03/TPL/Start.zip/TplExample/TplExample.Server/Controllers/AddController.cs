﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace TplExample.Server.Controllers {
    [Produces("application/json")]
    [Route("api/Add")]
    public class AddController : Controller {
        [HttpGet]
        public double Get(double a, double b) {
            Task.Delay(1000).Wait();
            return a + b;
        }
    }
}
