﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace TplExample.Client {
    class Program {
        static void Main(string[] args) {
            var tuples = new List<ValueTuple<double, double>>();
            for (int i = 0; i < 100; i++) {
                tuples.Add((i, i));
            }

            var httpClient = new HttpClient();
            var options = new ParallelOptions { MaxDegreeOfParallelism = 10 };
            Parallel.ForEach(tuples, options, (tuple) => {
                double a = tuple.Item1, b = tuple.Item2;
                var url = $"http://localhost:5000/api/add?a={a}&b={b}";
                var response = httpClient.GetAsync(url).Result;
                if (response.IsSuccessStatusCode) {
                    var result = response.Content.ReadAsStringAsync().Result;
                    Console.WriteLine($"{a}+{b}={result}");
                }
            });
        }
    }
}
