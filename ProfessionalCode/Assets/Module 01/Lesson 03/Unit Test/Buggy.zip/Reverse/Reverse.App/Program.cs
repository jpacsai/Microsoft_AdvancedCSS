﻿using System;
using Reverse.Tools;

namespace Reverse.App {
    class Program {
        static void Main(string[] args) {
            var wordHelper = new WordHelper();
            var chars = "Everything is hard before it is easy".ToCharArray();
            wordHelper.ReverseWords(chars);
            var result = new string(chars);
            Console.WriteLine(result);
        }
    }
}
