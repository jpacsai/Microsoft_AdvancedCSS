﻿using System;

namespace Reverse.Tools {
    public class WordHelper {
        public void ReverseWords(char[] chars) {
            int p = 0, q = 0;
            while (++q < chars.Length) {
                if (chars[q] == ' ') {
                    ReverseWord(chars, p, q - 1);
                    p = q + 1;
                }
            }
        }

        private void ReverseWord(char[] chars, int li, int hi) {
            while (li++ < hi--) {
                Swap(chars, li, hi);
            }
        }

        private void Swap(char[] chars, int li, int hi) {
            char temp = chars[li];
            chars[li] = chars[hi];
            chars[hi] = temp;
        }
    }
}
