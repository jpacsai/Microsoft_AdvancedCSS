using System;
using Reverse.Tools;
using Xunit;

namespace Reverse.Test {
    public class WordHelperTest {
        [Fact]
        public void ReverseWords_OK() {
            var wordHelper = new WordHelper();
            var chars = "ABCDEFG ABCDEFGH ABCD".ToCharArray();
            wordHelper.ReverseWords(chars);
            var actual = new string(chars);
            //Console.WriteLine(result); // old code
            var expected = "GFEDCBA HGFEDCBA DCBA";
            Assert.Equal(expected, actual);
        }

        [Fact]
        public void ReverseWord_OK() {
            var wordHelper = new WordHelper();
            var chars = "ABCDEFGH".ToCharArray();
            wordHelper.ReverseWord(chars, 0, chars.Length - 1);
            var actual = new string(chars);
            var expected = "HGFEDCBA";
            Assert.Equal(expected, actual);
        }

        [Fact]
        public void Swap_OK() {
            var wordHelper = new WordHelper();
            var chars = "ABCDEFGH".ToCharArray();
            wordHelper.Swap(chars, 0, 7);
            wordHelper.Swap(chars, 1, 6);
            wordHelper.Swap(chars, 2, 5);
            wordHelper.Swap(chars, 3, 4);
            var actual = new string(chars);
            var expected = "HGFEDCBA";
            Assert.Equal(expected, actual);
        }
    }
}
