﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Reverse.Test")]
