﻿using System;

namespace IspAndSrpExample {
    class Program {
        static void Main(string[] args) {
            var tim = new Human();
            var phil = new Human();
            var clark = new Superman();
            tim.TalkTo(phil);
            tim.TalkTo(clark);
        }
    }

    interface ITalk {
        void Talk();
    }

    interface IFly {
        void Fly();
    }

    interface ISuperHuman : ITalk, IFly {
    }

    class Superman : ISuperHuman {
        public void Fly() {
            Console.WriteLine("I can fly!");
        }

        public void Talk() {
            Console.WriteLine("Hey, how are you!");
        }
    }

    class Human : ITalk {
        public void Talk() {
            Console.WriteLine("Hey, how are you!");
        }

        public void TalkTo(ITalk human) {
            Console.WriteLine("Hey, how are you!");
            human.Talk();
        }
    }
}
