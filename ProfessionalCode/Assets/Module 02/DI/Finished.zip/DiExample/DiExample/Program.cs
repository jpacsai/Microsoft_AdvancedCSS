﻿using System;
using Microsoft.Extensions.DependencyInjection;

namespace DiExample {
    class Program {
        static void Main(string[] args) {
            var serviceProvider = new ServiceCollection()
                .AddScoped(typeof(IVehicle), typeof(Truck)) // register service class
                .AddScoped<Driver>() // register service consumer class
                .BuildServiceProvider();

            var driver = serviceProvider.GetService<Driver>(); // constructor injection
            driver.Drive();
        }
    }

    interface IVehicle {
        void Run();
    }

    class Car : IVehicle {
        public void Run() {
            Console.WriteLine("The car is running ...");
        }
    }

    class Truck : IVehicle {
        public void Run() {
            Console.WriteLine("The truck is running ...");
        }
    }

    class Driver {
        private IVehicle _vehicle;
        public Driver(IVehicle vehicle) {
            _vehicle = vehicle;
        }

        public void Drive() {
            _vehicle.Run();
        }
    }
}
