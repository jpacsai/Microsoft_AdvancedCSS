﻿using System;

namespace DependencyExample {
    class Program {
        static void Main(string[] args) {
            var car = new Car();
            var truck = new Truck();
            var carDriver = new CarDriver(car);
            var truckDriver = new TruckDriver(truck);
            carDriver.Drive();
            truckDriver.Drive();
            var driver1 = new Driver(car);
            var driver2 = new Driver(truck);
            driver1.Drive();
            driver2.Drive();
        }
    }

    interface IVehicle {
        void Run();
    }

    class Car : IVehicle {
        public void Run() {
            Console.WriteLine("The car is running ...");
        }
    }

    class Truck : IVehicle {
        public void Run() {
            Console.WriteLine("The truck is running ...");
        }
    }

    class Driver {
        private IVehicle _vehicle;
        public Driver(IVehicle vehicle) {
            _vehicle = vehicle;
        }

        public void Drive() {
            _vehicle.Run();
        }
    }

    class CarDriver {
        private Car _car;
        public CarDriver(Car car) {
            _car = car;
        }

        public void Drive() {
            _car.Run();
        }
    }

    class TruckDriver {
        private Truck _truck;
        public TruckDriver(Truck truck) {
            _truck = truck;
        }

        public void Drive() {
            _truck.Run();
        }
    }
}
