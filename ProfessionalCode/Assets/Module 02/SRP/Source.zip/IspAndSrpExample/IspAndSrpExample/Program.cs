﻿using System;

namespace IspAndSrpExample {
    class Program {
        static void Main(string[] args) {
            var rocketMan = new FlyingHuman(new Rocket());
            var ironman = new FlyingHuman(new ParticleEngine());
            rocketMan.Fly();
            ironman.Fly();
        }
    }

    interface IFlightEquipment {
        void Fly();
    }

    class Rocket : IFlightEquipment {
        public void Fly() {
            Console.WriteLine("Rocket is working ...");
        }
    }

    class ParticleEngine : IFlightEquipment {
        public void Fly() {
            Console.WriteLine("Particle engine is working ...");
        }
    }

    class FlyingHuman {
        private IFlightEquipment _flightEquipment;

        public FlyingHuman(IFlightEquipment equipment) {
            _flightEquipment = equipment;
        }

        public void Fly() {
            _flightEquipment.Fly();
        }
    }
}
